USE platnosci
GO
;
DROP TABLE #koszty
CREATE TABLE #koszty
	(
		Id_faktura INT
		,rodzaj_wydatku VARCHAR(10)
		,Data_wyst DATETIME
		,Kwota_netto DECIMAL(9,2)
		,Waluta_faktura VARCHAR(3)
	)

INSERT INTO #koszty
SELECT	fa.Id_faktura
		,rw.Rodzaj_wyd
		,fa.Data_wyst
		,fa.Kwota_netto
		,fa.Waluta_faktura
FROM
	dbo.FAKTURA AS fa
	INNER JOIN dbo.RODZAJ_WYDATKU AS rw
	ON rw.Id_rodzaj_wyd = fa.Id_rodzaj_wyd
	INNER JOIN dbo.FORMA_PLATNOSCI AS fp
	ON fp.Id_forma_platn = fa.Id_forma_platn
	INNER JOIN dbo.FIRMA AS fi
	ON fi.Id_firma = fa.Id_firma

	SELECT k.rodzaj_wydatku
			,Year(k.Data_wyst) AS [Rok]
			,Month(k.Data_wyst) AS [Miesi�c]
			,SUM(k.Kwota_netto) AS [Suma]
			,k.Waluta_faktura
	FROM 
		#koszty as k

	GROUP BY
		Year(k.Data_wyst)
		,k.rodzaj_wydatku		
		,Month(k.Data_wyst)
		,k.Waluta_faktura