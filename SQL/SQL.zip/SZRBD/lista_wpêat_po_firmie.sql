USE platnosci
GO
;

SELECT
		fp.Id_firma
		,fp.Id_faktura
		,fp.Nazwa_firma_skrot
		,ISNULL([dbo].[data_formatuj](bp.Data_platn), '-') AS[Data_wplaty]
		,ISNULL([dbo].[Nr_konta_format](bp.Nr_konta_odb), '-') AS[Nr konta]
		,fp.Nr_faktury
		,[dbo].[data_formatuj](fp.Data_wyst) AS [Data_wyst]
		,[dbo].[data_formatuj](fp.Termin_platn) AS [Termin_platn]
		,[dbo].[kwota_formatuj](fp.Kwota_brutto) AS [Kwota_brutto]
		,fp.Waluta_faktura
		,ISNULL([dbo].[kwota_formatuj](bp.Kwota_platn), '-') AS [Wplata]
		

FROM 
	[dbo].[fakturaPolaczone]() AS fp
FULL OUTER JOIN [dbo].[bankPlatnosci]() as bp
	ON bp.Id_faktura = fp.Id_faktura
WHERE fp.Id_firma = 10005
ORDER BY
	bp.Data_platn DESC
	