--INSERT INTO [dbo].[FIRMA](Nazwa_firma, Nip, Adres)
--VALUES ('Januszex', 987654321, 'Kluczbork, ul. Grudzi�dzka 15'),
--('Murarz', 987654312, 'Koszalin, ul. Murarska 2'),
--('Weterynarz', 987654352, 'Koszalin, ul. Ma�pia 38'),
--('Dentysta', 987654352, 'Koszalin, ul. Wyrwiz�ba 145'),
--('Us�ugi krawieckie', 123456789, 'Koszalin, ul. Ig�y i nitki 1')
--;

--INSERT INTO [dbo].[FAKTURA](Id_firma, Nr_faktury, Data_wyst, Termin_platn, Kwota_do_zaplaty)
--VALUES
--(2, 'FAK445', 2020-12-08, 2020-12-10, 1000.00 ),
--(2, 'FAK450', 2020-12-01, 2020-12-25, 1800.00 ),
--(5, '450', 2020-11-01, 2020-12-01, 25.00 ),
--(4, '1', 2020-11-15, 2020-12-07, 12250.00 ),
--(5, '22/12/FVS', 2020-12-15, 2020-12-22, -1400.00)
--;

SELECT Nr_faktury, Kwota_brutto FROM[dbo].[FAKTURA]
WHERE Id_firma = 2;

SELECT Id_firma, Nr_faktury, Kwota_brutto FROM[dbo].[FAKTURA]
WHERE Data_wyst < CONVERT(datetime, '2020-12-02'); 

--po nazwie firmy
SELECT [dbo].[FIRMA].Nazwa_firma, [dbo].[FAKTURA].Nr_faktury,[dbo].[FAKTURA].Termin_platn, [dbo].[FAKTURA].Kwota_brutto
FROM [dbo].[FAKTURA]
INNER JOIN [dbo].[FIRMA]  ON [dbo].[FAKTURA].Id_firma = [dbo].[FIRMA].Id_firma
WHERE [dbo].[FIRMA].Nazwa_firma = 'Eleiko'
;

--po dacie p�atn
SELECT [dbo].[FIRMA].Nazwa_firma, [dbo].[FAKTURA].Nr_faktury,[dbo].[FAKTURA].Termin_platn, [dbo].[FAKTURA].Kwota_brutto
FROM [dbo].[FAKTURA]
INNER JOIN [dbo].[FIRMA]  ON [dbo].[FAKTURA].Id_firma = [dbo].[FIRMA].Id_firma
WHERE Termin_platn > CONVERT(datetime, '2020-12-01'); 
;

--po kwocie
SELECT [dbo].[FIRMA].Nazwa_firma, [dbo].[FAKTURA].Nr_faktury,[dbo].[FAKTURA].Termin_platn, [dbo].[FAKTURA].Kwota_brutto
FROM [dbo].[FAKTURA]
INNER JOIN [dbo].[FIRMA]  ON [dbo].[FAKTURA].Id_firma = [dbo].[FIRMA].Id_firma
WHERE Kwota_brutto < 0; 
;