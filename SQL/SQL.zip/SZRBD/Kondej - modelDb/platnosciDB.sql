/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2012                    */
/* Created on:     2020-12-12 21:12:58                          */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('FAKTURA') and o.name = 'FK_FAKTURA_WYSTAWIL_FIRMA')
alter table FAKTURA
   drop constraint FK_FAKTURA_WYSTAWIL_FIRMA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('FAKTURA') and o.name = 'FK_FAKTURA_MA_RODZAJ_W')
alter table FAKTURA
   drop constraint FK_FAKTURA_MA_RODZAJ_W
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('FAKTURA') and o.name = 'FK_FAKTURA_PLATNA ZA_FORMA_PL')
alter table FAKTURA
   drop constraint "FK_FAKTURA_PLATNA ZA_FORMA_PL"
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('KONTO_BANKOWE') and o.name = 'FK_KONTO_BA_POSIADA_FIRMA')
alter table KONTO_BANKOWE
   drop constraint FK_KONTO_BA_POSIADA_FIRMA
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PLATNOSC') and o.name = 'FK_PLATNOSC_PLATNOSC _KONTO_BA')
alter table PLATNOSC
   drop constraint "FK_PLATNOSC_PLATNOSC _KONTO_BA"
go

if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('PLATNOSC') and o.name = 'FK_PLATNOSC_ZAWIERA_FAKTURA')
alter table PLATNOSC
   drop constraint FK_PLATNOSC_ZAWIERA_FAKTURA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('FAKTURA')
            and   name  = 'platna za pomoca_FK'
            and   indid > 0
            and   indid < 255)
   drop index FAKTURA."platna za pomoca_FK"
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('FAKTURA')
            and   name  = 'ma_FK'
            and   indid > 0
            and   indid < 255)
   drop index FAKTURA.ma_FK
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('FAKTURA')
            and   name  = 'Wystawil_FK'
            and   indid > 0
            and   indid < 255)
   drop index FAKTURA.Wystawil_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('FAKTURA')
            and   type = 'U')
   drop table FAKTURA
go

if exists (select 1
            from  sysobjects
           where  id = object_id('FIRMA')
            and   type = 'U')
   drop table FIRMA
go

if exists (select 1
            from  sysobjects
           where  id = object_id('FORMA_PLATNOSCI')
            and   type = 'U')
   drop table FORMA_PLATNOSCI
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('KONTO_BANKOWE')
            and   name  = 'posiada_FK'
            and   indid > 0
            and   indid < 255)
   drop index KONTO_BANKOWE.posiada_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('KONTO_BANKOWE')
            and   type = 'U')
   drop table KONTO_BANKOWE
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PLATNOSC')
            and   name  = 'platnosc na konto_FK'
            and   indid > 0
            and   indid < 255)
   drop index PLATNOSC."platnosc na konto_FK"
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('PLATNOSC')
            and   name  = 'zawiera_FK'
            and   indid > 0
            and   indid < 255)
   drop index PLATNOSC.zawiera_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('PLATNOSC')
            and   type = 'U')
   drop table PLATNOSC
go

if exists (select 1
            from  sysobjects
           where  id = object_id('RODZAJ_WYDATKU')
            and   type = 'U')
   drop table RODZAJ_WYDATKU
go

/*==============================================================*/
/* Table: FAKTURA                                               */
/*==============================================================*/
create table FAKTURA (
   Id_faktura           numeric              identity,
   Id_rodzaj_wyd        numeric              not null,
   Id_forma_platn       numeric              not null,
   Id_firma             numeric              not null,
   Nr_faktury           varchar(35)          not null,
   Data_wyst            datetime             not null,
   Termin_platn         datetime             not null,
   Kwota_netto          decimal(9,2)         not null,
   Kwota_vat            decimal(9,2)         not null,
   Kwota_brutto         decimal(9,2)         not null,
   Data_wprowadzenia    datetime             not null,
   Informacje_dod       varchar(65)          null,
   Waluta_faktura       varchar(3)           not null,
   constraint PK_FAKTURA primary key nonclustered (Id_faktura)
)
go

/*==============================================================*/
/* Index: Wystawil_FK                                           */
/*==============================================================*/
create index Wystawil_FK on FAKTURA (
Id_firma ASC
)
go

/*==============================================================*/
/* Index: ma_FK                                                 */
/*==============================================================*/
create index ma_FK on FAKTURA (
Id_rodzaj_wyd ASC
)
go

/*==============================================================*/
/* Index: "platna za pomoca_FK"                                 */
/*==============================================================*/
create index "platna za pomoca_FK" on FAKTURA (
Id_forma_platn ASC
)
go

/*==============================================================*/
/* Table: FIRMA                                                 */
/*==============================================================*/
create table FIRMA (
   Id_firma             numeric              identity,
   Nazwa_firma          varchar(45)          null,
   Nazwa_firma_skrot    varchar(10)          not null,
   Nip                  char(9)              null,
   Adres_firma          varchar(45)          null,
   Kraj_firma           char(3)              null,
   constraint PK_FIRMA primary key nonclustered (Id_firma)
)
go

/*==============================================================*/
/* Table: FORMA_PLATNOSCI                                       */
/*==============================================================*/
create table FORMA_PLATNOSCI (
   Id_forma_platn       numeric              identity,
   forma_platn          varchar(10)          not null,
   constraint PK_FORMA_PLATNOSCI primary key nonclustered (Id_forma_platn)
)
go

/*==============================================================*/
/* Table: KONTO_BANKOWE                                         */
/*==============================================================*/
create table KONTO_BANKOWE (
   Id_konto_odb         numeric              identity,
   Id_firma             numeric              not null,
   Nr_konta_odb         char(26)             not null,
   Swift                char(8)              null,
   Waluta_konto         varchar(3)           not null,
   Typ                  bit                  not null,
   constraint PK_KONTO_BANKOWE primary key nonclustered (Id_konto_odb)
)
go

/*==============================================================*/
/* Index: posiada_FK                                            */
/*==============================================================*/
create index posiada_FK on KONTO_BANKOWE (
Id_firma ASC
)
go

/*==============================================================*/
/* Table: PLATNOSC                                              */
/*==============================================================*/
create table PLATNOSC (
   Id_platnosc          numeric              identity,
   Id_faktura           numeric              null,
   Id_konto_odb         numeric              not null,
   Kwota_platn          decimal(9,2)         not null,
   Data_platn           datetime             not null,
   constraint PK_PLATNOSC primary key nonclustered (Id_platnosc)
)
go

/*==============================================================*/
/* Index: zawiera_FK                                            */
/*==============================================================*/
create index zawiera_FK on PLATNOSC (
Id_faktura ASC
)
go

/*==============================================================*/
/* Index: "platnosc na konto_FK"                                */
/*==============================================================*/
create index "platnosc na konto_FK" on PLATNOSC (
Id_konto_odb ASC
)
go

/*==============================================================*/
/* Table: RODZAJ_WYDATKU                                        */
/*==============================================================*/
create table RODZAJ_WYDATKU (
   Id_rodzaj_wyd        numeric              identity,
   Rodzaj_wyd           varchar(14)          not null,
   constraint PK_RODZAJ_WYDATKU primary key nonclustered (Id_rodzaj_wyd)
)
go

alter table FAKTURA
   add constraint FK_FAKTURA_WYSTAWIL_FIRMA foreign key (Id_firma)
      references FIRMA (Id_firma)
go

alter table FAKTURA
   add constraint FK_FAKTURA_MA_RODZAJ_W foreign key (Id_rodzaj_wyd)
      references RODZAJ_WYDATKU (Id_rodzaj_wyd)
go

alter table FAKTURA
   add constraint "FK_FAKTURA_PLATNA ZA_FORMA_PL" foreign key (Id_forma_platn)
      references FORMA_PLATNOSCI (Id_forma_platn)
go

alter table KONTO_BANKOWE
   add constraint FK_KONTO_BA_POSIADA_FIRMA foreign key (Id_firma)
      references FIRMA (Id_firma)
go

alter table PLATNOSC
   add constraint "FK_PLATNOSC_PLATNOSC _KONTO_BA" foreign key (Id_konto_odb)
      references KONTO_BANKOWE (Id_konto_odb)
go

alter table PLATNOSC
   add constraint FK_PLATNOSC_ZAWIERA_FAKTURA foreign key (Id_faktura)
      references FAKTURA (Id_faktura)
go

