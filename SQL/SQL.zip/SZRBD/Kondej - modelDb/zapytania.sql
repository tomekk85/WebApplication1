USE platnosci

SELECT Nr_faktury, Kwota_brutto FROM[dbo].[FAKTURA]
WHERE Id_firma = 2;

--wyszukiwanie faktur wystawionych przed
SELECT Id_firma, Nr_faktury, Kwota_brutto FROM[dbo].[FAKTURA]
WHERE Data_wyst < CONVERT(datetime, '2021-12-02'); 

--po dacie p�atn
SELECT [dbo].[FIRMA].Nazwa_firma_skrot, [dbo].[FAKTURA].Nr_faktury,[dbo].[FAKTURA].Termin_platn, [dbo].[FAKTURA].Kwota_brutto
FROM [dbo].[FAKTURA]
INNER JOIN [dbo].[FIRMA]  ON [dbo].[FAKTURA].Id_firma = [dbo].[FIRMA].Id_firma
WHERE Termin_platn > '2020-12-01'; 
;

--FUNKCJA Formatuj�ca nr konta

--firma + nr konta + NIP
SELECT [dbo].[FIRMA].Nazwa_firma_skrot, [dbo].[FIRMA].Nip, [dbo].[KONTO_BANKOWE].Nr_konta_odb, [dbo].[KONTO_BANKOWE].Waluta_konto, [dbo].[KONTO_BANKOWE].Swift
FROM [dbo].[KONTO_BANKOWE]
INNER JOIN [dbo].[FIRMA]  ON [dbo].[KONTO_BANKOWE].Id_firma = [dbo].[FIRMA].Id_firma
WHERE [dbo].[FIRMA].Id_firma = 1


--Lista faktur do zap�aty
SELECT [dbo].[FAKTURA].Id_firma, [dbo].[FAKTURA].Nr_faktury,[dbo].[FAKTURA].Termin_platn, 
[dbo].[FAKTURA].Kwota_brutto, [dbo].[PLATNOSC].Kwota_platn
FROM [dbo].[PLATNOSC]
INNER JOIN [dbo].[FAKTURA]  ON [dbo].[PLATNOSC].Id_faktura = [dbo].[FAKTURA].Id_faktura
;
USE platnosci
--Grupowanie
SELECT [dbo].[PLATNOSC].Id_faktura, SUM([dbo].[PLATNOSC].Kwota_platn)
FROM [dbo].[PLATNOSC]
GROUP BY [dbo].[PLATNOSC].Id_faktura;


;

--po kwocie
SELECT [dbo].[FIRMA].Nazwa_firma, [dbo].[FAKTURA].Nr_faktury,[dbo].[FAKTURA].Termin_platn, [dbo].[FAKTURA].Kwota_brutto
FROM [dbo].[FAKTURA]
INNER JOIN [dbo].[FIRMA]  ON [dbo].[FAKTURA].Id_firma = [dbo].[FIRMA].Id_firma
;