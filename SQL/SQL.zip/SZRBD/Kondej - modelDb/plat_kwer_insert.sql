
[dbo].[FAKTURA]+
[dbo].[FIRMA]+
[dbo].[FORMA_PLATNOSCI]+
[dbo].[KONTO_BANKOWE]+
[dbo].[PLATNOSC]
[dbo].[RODZAJ_WYDATKU]+
szablon
INSERT INTO [dbo].[]()
VALUES()

INSERT INTO [dbo].[PLATNOSC](Id_faktura, Id_konto_odb, Kwota_platn, Data_platn)
VALUES
(5, 1, 500,CONVERT(datetime, '2020-12-11')),
(6, 1, 500.23,CONVERT(datetime, '2020-12-12')),
(5, 1, 200,CONVERT(datetime, '2020-12-12'))
;

INSERT INTO [dbo].[FAKTURA](Id_rodzaj_wyd, Id_forma_platn, Id_firma, Nr_faktury, Data_wyst, Termin_platn,
							Kwota_netto,Kwota_vat, Kwota_brutto, Data_wprowadzenia, Informacje_dod, Waluta_faktura)
VALUES(1, 1, 1, 'FA 123', CONVERT(datetime, '2020-12-02'), CONVERT(datetime, '2020-12-10'),
		1000.00, 230.00, 1230.00,CONVERT(datetime, '2020-12-12'),NULL,'PLN'),
		(1, 2, 2, '222/12/FVS', CONVERT(datetime, '2020-12-01'), CONVERT(datetime, '2020-12-15'),
		4000.00, 920.00, 4920.00,CONVERT(datetime, '2020-12-12'),NULL,'PLN')
;


INSERT INTO [dbo].[KONTO_BANKOWE](Id_firma, Nr_konta_odb, Swift, Waluta_konto, Typ)
VALUES
(1,'21175014556924630548556916', 'ALBPPLPW', 'PLN', 1),
(2,'30195000012997961162312653', 'WBKPPLPP', 'PLN', 1),
(3,'88105019794312927657146159', 'NDEASESS', 'SEK', 1)
;




INSERT INTO [dbo].[FIRMA](Nazwa_firma, Nazwa_firma_skrot, Nip, Adres_firma, Kraj_firma)
VALUES
('Zak�ad fryzjerski', 'fryzjer-1', '987456321', '76-200 S�upsk, ul. Fryzjerska 55', 'POL'),
('Przedsi�biorstwo Gospodarki Komunalnej', 'PGK', '999999999', '76-200 S�upsk, ul. �mieciowa 15', 'POL'),
('Eleiko ', 'Eleiko', '777777777', 'Klastorpsv�gen 18, 302 62 Halmstad, ', 'SWE')
;

INSERT INTO [dbo].[RODZAJ_WYDATKU](Rodzaj_wyd)
	VALUES
	('produkcja'),
	('op�aty sta�e'),
	('transport'),
	('us�ugi'),
	('podatki'),
	('inne')
;

INSERT INTO [dbo].[FORMA_PLATNOSCI](forma_platn)
	VALUES
	('got�wka'),
	('karta'),
	('kompensata')
;