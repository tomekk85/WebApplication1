USE platnosci

DROP TABLE #bank_platnosci
CREATE TABLE #bank_platnosci
	(
	ID_firma INT
	,Id_faktura INT
	,Kwota_platn INT
	,Nr_konta VARCHAR(MAX)


	)

INSERT INTO #bank_platnosci

SELECT 
		kb.Id_firma
		,pl.Id_faktura
		,SUM(pl.Kwota_platn)
		,kb.Nr_konta_odb
FROM 
	PLATNOSC AS pl
	INNER JOIN KONTO_BANKOWE AS kb
	ON kb.Id_konto_odb = pl.Id_konto_odb
GROUP BY
	pl.Id_faktura, kb.Nr_konta_odb,kb.Id_firma
;
DROP TABLE #faktura_polaczone
CREATE TABLE #faktura_polaczone
	(
		Id_firma INT
		,Id_faktura INT
		,Nazwa_firma_skrot VARCHAR(10)
		,forma_platn VARCHAR(10)
		,Nr_faktury VARCHAR(35)
		,Data_wyst DATETIME
		,Termin_platn DATETIME
		,Kwota_brutto DECIMAL(9,2)
		,Waluta_faktura VARCHAR(3)
	)

INSERT INTO #faktura_polaczone
SELECT  fa.Id_firma
		,fa.Id_faktura
		,fi.Nazwa_firma_skrot
		,fp.forma_platn
		,fa.Nr_faktury
		,fa.Data_wyst
		,fa.Termin_platn
		,fa.Kwota_brutto
		,fa.Waluta_faktura
FROM
	dbo.FAKTURA AS fa
	INNER JOIN dbo.RODZAJ_WYDATKU AS rw
	ON rw.Id_rodzaj_wyd = fa.Id_rodzaj_wyd
	INNER JOIN dbo.FORMA_PLATNOSCI AS fp
	ON fp.Id_forma_platn = fa.Id_forma_platn
	INNER JOIN dbo.FIRMA AS fi
	ON fi.Id_firma = fa.Id_firma

SELECT
		fp.Id_firma
		,fp.Id_faktura
		,fp.Nazwa_firma_skrot
		,fp.forma_platn
		,fp.Nr_faktury
		,[dbo].[data_formatuj](fp.Data_wyst) AS [Data_wyst]
		,[dbo].[data_formatuj](fp.Termin_platn) AS [Termin_platn]
		,[dbo].[kwota_formatuj](fp.Kwota_brutto) AS [Kwota_brutto]
		,fp.Waluta_faktura
		,ISNULL([dbo].[kwota_formatuj](bp.Kwota_platn), 0.00) AS [Wplata_razem]
		,[dbo].[kwota_formatuj](fp.Kwota_brutto - ISNULL([dbo].[kwota_formatuj](bp.Kwota_platn), 0.00)) AS [Pozostaje_do_zap�]
		,ISNULL([dbo].[Nr_konta_format](bp.Nr_konta), '-') AS[Nr_konta]

FROM 
	#faktura_polaczone AS fp
FULL OUTER JOIN #bank_platnosci as bp
	ON bp.Id_faktura = fp.Id_faktura
WHERE fp.forma_platn = 'przelew'
AND (fp.Kwota_brutto > bp.Kwota_platn OR bp.Kwota_platn IS NULL)
