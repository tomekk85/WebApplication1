/*==============================================================*/
/* DBMS name:      Microsoft SQL Server 2012                    */
/* Created on:     2020-12-12 12:37:51                          */
/*==============================================================*/


if exists (select 1
   from sys.sysreferences r join sys.sysobjects o on (o.id = r.constid and o.type = 'F')
   where r.fkeyid = object_id('FAKTURA') and o.name = 'FK_FAKTURA_RELATIONS_FIRMA')
alter table FAKTURA
   drop constraint FK_FAKTURA_RELATIONS_FIRMA
go

if exists (select 1
            from  sysindexes
           where  id    = object_id('FAKTURA')
            and   name  = 'Relationship_1_FK'
            and   indid > 0
            and   indid < 255)
   drop index FAKTURA.Relationship_1_FK
go

if exists (select 1
            from  sysobjects
           where  id = object_id('FAKTURA')
            and   type = 'U')
   drop table FAKTURA
go

if exists (select 1
            from  sysobjects
           where  id = object_id('FIRMA')
            and   type = 'U')
   drop table FIRMA
go

/*==============================================================*/
/* Table: FAKTURA                                               */
/*==============================================================*/
create table FAKTURA (
   Id_faktura           numeric              identity,
   Id_firma             numeric              not null,
   Nr_faktura           varchar(25)          not null,
   Data_wyst            datetime             not null,
   Termin_plat          datetime             not null,
   Kwota_do_zaplaty     decimal              not null,
   constraint PK_FAKTURA primary key nonclustered (Id_faktura)
)
go

/*==============================================================*/
/* Index: Relationship_1_FK                                     */
/*==============================================================*/
create index Relationship_1_FK on FAKTURA (
Id_firma ASC
)
go

/*==============================================================*/
/* Table: FIRMA                                                 */
/*==============================================================*/
create table FIRMA (
   Id_firma             numeric              identity,
   Nazwa_firma          varchar(30)          not null,
   Nip                  numeric              null,
   Adres                varchar(55)          null,
   constraint PK_FIRMA primary key nonclustered (Id_firma)
)
go

alter table FAKTURA
   add constraint FK_FAKTURA_RELATIONS_FIRMA foreign key (Id_firma)
      references FIRMA (Id_firma)
go

