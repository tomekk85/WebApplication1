USE platnosci
GO

SELECT 
		pl.Id_faktura,
		kb.Id_firma
		,SUM(pl.Kwota_platn) AS [zap�acono]
		,kb.Nr_konta_odb
FROM 
	PLATNOSC AS pl
	INNER JOIN KONTO_BANKOWE AS kb
	ON kb.Id_konto_odb = pl.Id_konto_odb
GROUP BY
	pl.Id_faktura, kb.Nr_konta_odb,kb.Id_firma
