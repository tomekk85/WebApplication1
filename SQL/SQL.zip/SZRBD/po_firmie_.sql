USE platnosci
GO
;

CREATE FUNCTION fakturaPolaczone()
RETURNS TABLE
AS
RETURN
SELECT  fa.Id_firma
		,fa.Id_faktura
		,fi.Nazwa_firma_skrot
		,fp.forma_platn
		,fa.Nr_faktury
		,fa.Data_wyst
		,fa.Termin_platn
		,fa.Kwota_brutto
		,fa.Waluta_faktura
FROM
	dbo.FAKTURA AS fa
	INNER JOIN dbo.RODZAJ_WYDATKU AS rw
	ON rw.Id_rodzaj_wyd = fa.Id_rodzaj_wyd
	INNER JOIN dbo.FORMA_PLATNOSCI AS fp
	ON fp.Id_forma_platn = fa.Id_forma_platn
	INNER JOIN dbo.FIRMA AS fi
	ON fi.Id_firma = fa.Id_firma


