USE platnosci
GO
CREATE PROCEDURE dbo.fakturaWidok1
AS
BEGIN

SELECT  fa.Id_faktura,
		fi.Nazwa_firma_skrot,
		rw.Rodzaj_wyd,
		fp.forma_platn,
		fa.Nr_faktury,
		CONVERT(nvarchar(10), fa.Data_wyst, 23) AS [Data_wyst],
		CONVERT(nvarchar(10), fa.Termin_platn, 23) AS [Termin_platn],
		fa.Kwota_brutto,
		fa.Waluta_faktura

FROM
	dbo.FAKTURA AS fa
	INNER JOIN dbo.RODZAJ_WYDATKU AS rw
	ON rw.Id_rodzaj_wyd = fa.Id_rodzaj_wyd
	INNER JOIN dbo.FORMA_PLATNOSCI AS fp
	ON fp.Id_forma_platn = fa.Id_forma_platn
	INNER JOIN dbo.FIRMA AS fi
	ON fi.Id_firma = fa.Id_firma

END